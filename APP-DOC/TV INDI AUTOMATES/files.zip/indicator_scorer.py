"""
indicator_scorer.py
-------------------
Scores and ranks TradingView-style indicators by IC, ICIR, decay half-life,
regime breadth, and FDR-corrected significance.

Usage:
    python indicator_scorer.py --data btc_1d.csv --output ranked_indicators.csv

Requires: numpy pandas scipy statsmodels
"""

import numpy as np
import pandas as pd
from scipy import stats
from dataclasses import dataclass, field
from typing import Callable, Optional
import warnings
warnings.filterwarnings("ignore")


# ─────────────────────────────────────────────────────────────────────────────
# Signal library — each entry is a function: df → pd.Series (signal values)
# These correspond to Pine Script logic translated to Python.
# ─────────────────────────────────────────────────────────────────────────────

def smma(series: pd.Series, length: int) -> pd.Series:
    """Smoothed moving average (Pine Script style)."""
    result = np.full(len(series), np.nan)
    for i in range(len(series)):
        if i < length - 1:
            continue
        if i == length - 1:
            result[i] = series.iloc[:length].mean()
        else:
            result[i] = (result[i - 1] * (length - 1) + series.iloc[i]) / length
    return pd.Series(result, index=series.index)


def sig_kernel_regression(df: pd.DataFrame, h: float = 8.0, mult: float = 1.0) -> pd.Series:
    """
    Nadaraya–Watson kernel regression (Gaussian kernel).
    Signal = z-score of (close - kernel estimate) / ATR.
    """
    close = df["close"].values
    n = len(close)
    weights = np.zeros((n, n))
    for i in range(n):
        dists = np.arange(n) - i
        weights[i] = np.exp(-(dists ** 2) / (h ** 2 * 2))
        weights[i, i + 1:] = 0          # causal only — no future data
        w_sum = weights[i].sum()
        if w_sum > 0:
            weights[i] /= w_sum
    kernel_est = weights @ close
    atr = df["high"].rolling(14).max() - df["low"].rolling(14).min()
    raw = (df["close"] - pd.Series(kernel_est, index=df.index)) / atr.clip(lower=1e-9)
    return raw.rolling(5).mean()         # mild smoothing


def sig_gaussian_channel(df: pd.DataFrame, poles: int = 4, period: int = 144) -> pd.Series:
    """
    Gaussian channel midline signal.
    Signal = +1 when price above channel, -1 when below, 0 inside.
    We return the continuous z-score version for IC computation.
    """
    close = df["close"]
    beta = (1 - np.cos(2 * np.pi / period)) / (np.sqrt(2) ** (2 / poles) - 1)
    alpha = -beta + np.sqrt(beta**2 + 2 * beta)

    filtered = close.copy().astype(float)
    for _ in range(poles):
        filtered = filtered.ewm(alpha=alpha, adjust=False).mean()

    atr = df["high"].rolling(period).max() - df["low"].rolling(period).min()
    mid = filtered
    upper = mid + atr * 0.5
    lower = mid - atr * 0.5
    signal = (close - mid) / (atr * 0.5 + 1e-9)
    return signal


def sig_adx_trend(df: pd.DataFrame, length: int = 14) -> pd.Series:
    """ADX-based trend signal. Returns ADX z-score (strength, not direction)."""
    high, low, close = df["high"], df["low"], df["close"]
    tr = pd.concat([
        high - low,
        (high - close.shift()).abs(),
        (low - close.shift()).abs()
    ], axis=1).max(axis=1)

    plus_dm = (high - high.shift()).clip(lower=0)
    minus_dm = (low.shift() - low).clip(lower=0)
    plus_dm[plus_dm <= (low.shift() - low).clip(lower=0)] = 0
    minus_dm[minus_dm <= (high - high.shift()).clip(lower=0)] = 0

    atr = tr.ewm(span=length, adjust=False).mean()
    plus_di = 100 * plus_dm.ewm(span=length, adjust=False).mean() / atr
    minus_di = 100 * minus_dm.ewm(span=length, adjust=False).mean() / atr
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di + 1e-9)
    adx = dx.ewm(span=length, adjust=False).mean()
    direction = np.sign(plus_di - minus_di)
    return adx * direction / 25.0       # normalize to ~[-4, 4]


def sig_rsi_divergence(df: pd.DataFrame, length: int = 14, lookback: int = 5) -> pd.Series:
    """
    RSI momentum signal with divergence component.
    Raw RSI centered and normalized.
    """
    delta = df["close"].diff()
    gain = delta.clip(lower=0).ewm(span=length, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(span=length, adjust=False).mean()
    rs = gain / (loss + 1e-9)
    rsi = 100 - 100 / (1 + rs)
    centered = (rsi - 50) / 25.0        # map [0,100] → [-2, 2]

    # divergence component: price higher but RSI lower = bearish div
    price_change = df["close"].pct_change(lookback)
    rsi_change = rsi.diff(lookback) / 25.0
    divergence = rsi_change - price_change     # positive = bullish RSI strength

    return centered * 0.6 + divergence * 0.4


def sig_atr_regime(df: pd.DataFrame, length: int = 14, smooth: int = 50) -> pd.Series:
    """
    Volatility regime signal.
    Low ATR relative to history = trending (positive), high = ranging (negative).
    """
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - df["close"].shift()).abs(),
        (df["low"] - df["close"].shift()).abs()
    ], axis=1).max(axis=1)
    atr = tr.ewm(span=length, adjust=False).mean()
    atr_norm = (atr - atr.rolling(smooth).mean()) / (atr.rolling(smooth).std() + 1e-9)
    return -atr_norm                    # inverted: low vol = good for trend signals


def sig_macd_histogram(df: pd.DataFrame, fast: int = 12, slow: int = 26, signal_len: int = 9) -> pd.Series:
    """MACD histogram normalized by close price."""
    ema_fast = df["close"].ewm(span=fast, adjust=False).mean()
    ema_slow = df["close"].ewm(span=slow, adjust=False).mean()
    macd = ema_fast - ema_slow
    signal = macd.ewm(span=signal_len, adjust=False).mean()
    hist = (macd - signal) / (df["close"] + 1e-9) * 100
    return hist


def sig_vwap_deviation(df: pd.DataFrame, length: int = 20) -> pd.Series:
    """Rolling VWAP deviation. Requires volume."""
    if "volume" not in df.columns:
        return pd.Series(np.nan, index=df.index)
    typical = (df["high"] + df["low"] + df["close"]) / 3
    vol = df["volume"]
    vwap = (typical * vol).rolling(length).sum() / vol.rolling(length).sum()
    atr = (df["high"].rolling(length).max() - df["low"].rolling(length).min())
    dev = (df["close"] - vwap) / (atr + 1e-9)
    return dev


def sig_supertrend(df: pd.DataFrame, length: int = 10, mult: float = 3.0) -> pd.Series:
    """
    Supertrend signal: +1 = bullish, -1 = bearish.
    Returns continuous version for IC computation.
    """
    hl2 = (df["high"] + df["low"]) / 2
    atr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - df["close"].shift()).abs(),
        (df["low"] - df["close"].shift()).abs()
    ], axis=1).max(axis=1).rolling(length).mean()

    upper = hl2 + mult * atr
    lower = hl2 - mult * atr

    supertrend = pd.Series(np.nan, index=df.index)
    direction = pd.Series(1, index=df.index)

    for i in range(1, len(df)):
        prev_upper = upper.iloc[i-1] if not np.isnan(upper.iloc[i-1]) else upper.iloc[i]
        prev_lower = lower.iloc[i-1] if not np.isnan(lower.iloc[i-1]) else lower.iloc[i]

        upper.iloc[i] = min(upper.iloc[i], prev_upper) if df["close"].iloc[i-1] <= prev_upper else upper.iloc[i]
        lower.iloc[i] = max(lower.iloc[i], prev_lower) if df["close"].iloc[i-1] >= prev_lower else lower.iloc[i]

        if df["close"].iloc[i] > upper.iloc[i-1]:
            direction.iloc[i] = 1
        elif df["close"].iloc[i] < lower.iloc[i-1]:
            direction.iloc[i] = -1
        else:
            direction.iloc[i] = direction.iloc[i-1]

    # Continuous version: distance from active band
    st_val = np.where(direction == 1, lower, upper)
    raw = (df["close"].values - st_val) / (atr.values + 1e-9)
    return pd.Series(raw, index=df.index)


def sig_stoch_rsi(df: pd.DataFrame, rsi_len: int = 14, stoch_len: int = 14, k: int = 3, d: int = 3) -> pd.Series:
    """Stochastic RSI normalized to [-1, 1]."""
    delta = df["close"].diff()
    gain = delta.clip(lower=0).ewm(span=rsi_len, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(span=rsi_len, adjust=False).mean()
    rsi = 100 - 100 / (1 + gain / (loss + 1e-9))
    stoch = (rsi - rsi.rolling(stoch_len).min()) / (rsi.rolling(stoch_len).max() - rsi.rolling(stoch_len).min() + 1e-9)
    k_line = stoch.rolling(k).mean()
    d_line = k_line.rolling(d).mean()
    return (k_line - 0.5) * 2           # center at 0


def sig_cci(df: pd.DataFrame, length: int = 20) -> pd.Series:
    """Commodity Channel Index normalized."""
    typical = (df["high"] + df["low"] + df["close"]) / 3
    sma = typical.rolling(length).mean()
    mad = typical.rolling(length).apply(lambda x: np.abs(x - x.mean()).mean(), raw=True)
    return (typical - sma) / (0.015 * mad + 1e-9) / 100


# ─────────────────────────────────────────────────────────────────────────────
# Signal registry
# ─────────────────────────────────────────────────────────────────────────────

SIGNAL_REGISTRY: dict[str, dict] = {
    "kernel_regression":  {"fn": sig_kernel_regression,  "type": "trend",    "timeframe": "1D"},
    "gaussian_channel":   {"fn": sig_gaussian_channel,   "type": "trend",    "timeframe": "1D"},
    "adx_trend":          {"fn": sig_adx_trend,          "type": "regime",   "timeframe": "1D"},
    "rsi_divergence":     {"fn": sig_rsi_divergence,     "type": "momentum", "timeframe": "1D"},
    "atr_regime":         {"fn": sig_atr_regime,         "type": "vol",      "timeframe": "1D"},
    "macd_histogram":     {"fn": sig_macd_histogram,     "type": "momentum", "timeframe": "1D"},
    "vwap_deviation":     {"fn": sig_vwap_deviation,     "type": "struct",   "timeframe": "1D"},
    "supertrend":         {"fn": sig_supertrend,         "type": "trend",    "timeframe": "1D"},
    "stoch_rsi":          {"fn": sig_stoch_rsi,          "type": "momentum", "timeframe": "1D"},
    "cci":                {"fn": sig_cci,                "type": "momentum", "timeframe": "1D"},
}


# ─────────────────────────────────────────────────────────────────────────────
# Scoring engine
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class SignalScore:
    name: str
    sig_type: str
    ic_mean: float          # mean IC across all forward horizons
    icir: float             # IC / std(IC)  — information ratio of IC
    ic_by_horizon: dict     # {horizon_days: IC}
    half_life_days: float   # horizon at which IC drops to 50% of peak
    hit_rate: float         # fraction of periods where sign(signal) == sign(fwd_return)
    regime_breadth: float   # fraction of market regimes where IC > 0.02
    fdr_pvalue: float       # Benjamini-Hochberg corrected p-value
    composite_score: float  # final weighted score


def compute_forward_returns(close: pd.Series, horizon: int) -> pd.Series:
    """Log returns over forward horizon, shifted back so aligned with signal date."""
    log_ret = np.log(close / close.shift(1))
    return log_ret.shift(-horizon).rolling(horizon).sum()


def information_coefficient(signal: pd.Series, fwd_returns: pd.Series) -> float:
    """Pearson IC between signal and forward returns on overlapping non-NaN rows."""
    valid = signal.notna() & fwd_returns.notna()
    if valid.sum() < 30:
        return np.nan
    s = signal[valid].values
    r = fwd_returns[valid].values
    # Winsorize both at 1%/99% to reduce outlier sensitivity
    s = np.clip(s, np.nanpercentile(s, 1), np.nanpercentile(s, 99))
    r = np.clip(r, np.nanpercentile(r, 1), np.nanpercentile(r, 99))
    corr, _ = stats.pearsonr(s, r)
    return corr


def rolling_ic(signal: pd.Series, fwd_returns: pd.Series, window: int = 126) -> pd.Series:
    """Rolling window IC series."""
    valid_idx = signal.index.intersection(fwd_returns.index)
    sig = signal.reindex(valid_idx)
    ret = fwd_returns.reindex(valid_idx)

    ic_vals = []
    dates = []
    for end in range(window, len(valid_idx)):
        s_win = sig.iloc[end - window:end]
        r_win = ret.iloc[end - window:end]
        ic = information_coefficient(s_win, r_win)
        ic_vals.append(ic)
        dates.append(valid_idx[end])

    return pd.Series(ic_vals, index=dates)


def compute_half_life(ic_by_horizon: dict) -> float:
    """
    Fit exponential decay to IC vs horizon.
    Returns horizon (days) at which IC drops to 50% of peak.
    """
    horizons = sorted(ic_by_horizon.keys())
    ic_vals = [ic_by_horizon[h] for h in horizons]
    peak_ic = max(ic_vals, key=abs)
    if abs(peak_ic) < 1e-6:
        return 0.0
    for i, (h, ic) in enumerate(zip(horizons, ic_vals)):
        if abs(ic) <= abs(peak_ic) * 0.5:
            return float(h)
    return float(horizons[-1])


def compute_regime_breadth(
    signal: pd.Series,
    fwd_returns: pd.Series,
    close: pd.Series,
    min_ic: float = 0.02
) -> float:
    """
    Compute IC across 4 regime quadrants:
    Bull trend, Bear trend, Low vol, High vol.
    Returns fraction of regimes where IC > min_ic.
    """
    ma200 = close.rolling(200).mean()
    atr20 = (close.rolling(20).max() - close.rolling(20).min()) / close

    regimes = {
        "bull_trend":  (close > ma200) & (atr20 < atr20.rolling(100).median()),
        "bear_trend":  (close < ma200) & (atr20 < atr20.rolling(100).median()),
        "bull_vol":    (close > ma200) & (atr20 >= atr20.rolling(100).median()),
        "bear_vol":    (close < ma200) & (atr20 >= atr20.rolling(100).median()),
    }

    valid = 0
    total = 0
    for regime_mask in regimes.values():
        mask = regime_mask & signal.notna() & fwd_returns.notna()
        if mask.sum() < 20:
            continue
        ic = information_coefficient(signal[mask], fwd_returns[mask])
        total += 1
        if not np.isnan(ic) and ic > min_ic:
            valid += 1

    return valid / total if total > 0 else 0.0


def score_signal(
    name: str,
    sig_fn: Callable,
    df: pd.DataFrame,
    horizons: list[int] = [1, 5, 10, 21, 42, 63],
    ic_window: int = 126,
) -> Optional[SignalScore]:
    """Score a single signal function against OHLCV data."""
    try:
        signal = sig_fn(df)
    except Exception as e:
        print(f"  [!] {name} signal computation failed: {e}")
        return None

    ic_by_horizon = {}
    rolling_ics = {}

    for h in horizons:
        fwd = compute_forward_returns(df["close"], h)
        ic = information_coefficient(signal, fwd)
        ic_by_horizon[h] = ic if not np.isnan(ic) else 0.0

        ric = rolling_ic(signal, fwd, window=ic_window)
        rolling_ics[h] = ric

    # ICIR from the 10-day forward return horizon (medium-term)
    ref_horizon = 10
    if ref_horizon in rolling_ics:
        ric = rolling_ics[ref_horizon].dropna()
        ic_mean_ref = ric.mean()
        ic_std_ref = ric.std()
        icir = ic_mean_ref / (ic_std_ref + 1e-9) if ic_std_ref > 1e-6 else 0.0
    else:
        ic_mean_ref = np.nanmean(list(ic_by_horizon.values()))
        icir = 0.0

    # Hit rate at 10-day horizon
    fwd_10 = compute_forward_returns(df["close"], 10)
    valid = signal.notna() & fwd_10.notna()
    if valid.sum() > 20:
        correct = np.sign(signal[valid]) == np.sign(fwd_10[valid])
        hit_rate = correct.mean()
    else:
        hit_rate = 0.5

    half_life = compute_half_life(ic_by_horizon)
    regime_breadth = compute_regime_breadth(signal, fwd_10, df["close"])

    # Simple p-value from IC t-test (gets FDR corrected downstream)
    fwd_10 = compute_forward_returns(df["close"], 10)
    valid = signal.notna() & fwd_10.notna()
    n_valid = valid.sum()
    if n_valid > 30:
        ic_val = ic_by_horizon.get(10, 0.0)
        t_stat = ic_val * np.sqrt(n_valid - 2) / (np.sqrt(1 - ic_val**2) + 1e-9)
        pvalue = 2 * stats.t.sf(abs(t_stat), df=n_valid - 2)
    else:
        pvalue = 1.0

    # Composite score (weights tunable)
    ic_val = ic_by_horizon.get(10, 0.0)
    composite = (
        0.35 * np.clip(icir / 2.0, 0, 1) +         # ICIR (normalized to [0,1] at ICIR=2)
        0.25 * np.clip(abs(ic_val) / 0.15, 0, 1) +  # absolute IC magnitude
        0.20 * regime_breadth +                       # works in many regimes
        0.10 * hit_rate +                             # directional accuracy
        0.10 * np.clip(half_life / 21, 0, 1)         # signal persistence (favor ~21d)
    )

    return SignalScore(
        name=name,
        sig_type=SIGNAL_REGISTRY[name]["type"],
        ic_mean=float(ic_mean_ref),
        icir=float(icir),
        ic_by_horizon=ic_by_horizon,
        half_life_days=float(half_life),
        hit_rate=float(hit_rate),
        regime_breadth=float(regime_breadth),
        fdr_pvalue=float(pvalue),
        composite_score=float(composite),
    )


def fdr_correct(scores: list[SignalScore]) -> list[SignalScore]:
    """Apply Benjamini-Hochberg FDR correction to p-values."""
    from statsmodels.stats.multitest import multipletests
    pvals = [s.fdr_pvalue for s in scores]
    _, corrected, _, _ = multipletests(pvals, alpha=0.05, method="fdr_bh")
    for s, cp in zip(scores, corrected):
        s.fdr_pvalue = cp
    return scores


def rank_and_cluster(
    scores: list[SignalScore],
    max_corr: float = 0.70,
    top_n: int = 10,
) -> list[SignalScore]:
    """
    Remove dominated/redundant signals via pairwise signal correlation.
    Within each cluster (corr > max_corr), keep only the highest composite scorer.
    Returns top_n after deduplication.
    """
    sorted_scores = sorted(scores, key=lambda s: s.composite_score, reverse=True)
    # No real signal data here — just pass through.
    # In production: build signal matrix, compute pairwise corr,
    # greedily include signals that are < max_corr with all already-included.
    return sorted_scores[:top_n]


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def score_all_signals(df: pd.DataFrame, horizons: list[int] = [1, 5, 10, 21, 42]) -> pd.DataFrame:
    """
    Score every signal in the registry and return a ranked DataFrame.

    Parameters
    ----------
    df : DataFrame with columns [open, high, low, close, volume], DatetimeIndex
    horizons : forward return horizons to test IC at

    Returns
    -------
    DataFrame with one row per signal, sorted by composite_score descending
    """
    print(f"Scoring {len(SIGNAL_REGISTRY)} signals over {len(df)} bars...")
    raw_scores: list[SignalScore] = []

    for name, meta in SIGNAL_REGISTRY.items():
        print(f"  Scoring: {name}")
        score = score_signal(name, meta["fn"], df, horizons=horizons)
        if score is not None:
            raw_scores.append(score)

    # FDR correction across all tests
    try:
        raw_scores = fdr_correct(raw_scores)
    except ImportError:
        print("  [!] statsmodels not installed — skipping FDR correction")

    # Rank and cluster
    ranked = rank_and_cluster(raw_scores, top_n=10)

    rows = []
    for rank, s in enumerate(ranked, 1):
        rows.append({
            "rank":            rank,
            "name":            s.name,
            "type":            s.sig_type,
            "ic_10d":          round(s.ic_by_horizon.get(10, 0.0), 4),
            "ic_21d":          round(s.ic_by_horizon.get(21, 0.0), 4),
            "icir":            round(s.icir, 3),
            "half_life_days":  round(s.half_life_days, 1),
            "hit_rate":        round(s.hit_rate, 3),
            "regime_breadth":  round(s.regime_breadth, 3),
            "fdr_pvalue":      round(s.fdr_pvalue, 4),
            "composite_score": round(s.composite_score, 4),
        })

    return pd.DataFrame(rows)


# ─────────────────────────────────────────────────────────────────────────────
# CLI entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Score and rank trading indicators")
    parser.add_argument("--data",   required=True,  help="Path to OHLCV CSV (columns: date,open,high,low,close,volume)")
    parser.add_argument("--output", default="ranked_indicators.csv", help="Output CSV path")
    args = parser.parse_args()

    df = pd.read_csv(args.data, parse_dates=["date"], index_col="date")
    df.columns = df.columns.str.lower()

    start = "2018-01-01"
    df = df.loc[start:]
    print(f"Loaded {len(df)} bars from {df.index[0].date()} to {df.index[-1].date()}")

    result = score_all_signals(df)
    result.to_csv(args.output, index=False)
    print(f"\nTop 10 signals saved to {args.output}")
    print(result.to_string(index=False))
