// signal_combiner/src/main.rs
//
// Rust combination engine — takes ranked indicator signals, computes
// strength + alignment dimensions, outputs composite signal per bar.
//
// Hot path: ~2µs per bar on M1. Zero allocation per bar after init.
//
// Build: cargo build --release
// Usage: ./signal_combiner --signals signals.csv --output composite.csv

use std::collections::HashMap;
use std::fs::File;
use std::io::{BufReader, BufWriter, Write};
use std::path::PathBuf;

use clap::Parser;
use csv::ReaderBuilder;
use serde::{Deserialize, Serialize};

// ─────────────────────────────────────────────────────────────────────────────
// CLI
// ─────────────────────────────────────────────────────────────────────────────

#[derive(Parser, Debug)]
#[command(author, version, about = "Combine ranked indicator signals into a composite")]
struct Args {
    /// CSV of signals: date + one column per indicator (signal values)
    #[arg(long)]
    signals: PathBuf,

    /// CSV of scores from indicator_scorer.py (for ICIR weights)
    #[arg(long)]
    scores: PathBuf,

    /// Output CSV path
    #[arg(long, default_value = "composite.csv")]
    output: PathBuf,

    /// Rolling window for alignment covariance (bars)
    #[arg(long, default_value_t = 63)]
    align_window: usize,

    /// Minimum alignment score to include a signal in composite [0, 1]
    #[arg(long, default_value_t = 0.2)]
    min_alignment: f64,
}

// ─────────────────────────────────────────────────────────────────────────────
// Data types
// ─────────────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone)]
struct IndicatorMeta {
    name: String,
    sig_type: String,
    icir: f64,          // used as base weight
    composite_score: f64,
}

/// One bar's worth of signal values across all indicators
#[derive(Debug)]
struct SignalBar {
    date: String,
    values: Vec<f64>,    // aligned with indicator order
}

/// Per-bar output
#[derive(Debug, Serialize)]
struct CompositeBar {
    date: String,
    composite_signal: f64,     // final weighted signal [-inf, inf]
    signal_strength: f64,      // agreement-weighted magnitude [0, 1]
    signal_alignment: f64,     // fraction of signals pointing same direction [0, 1]
    trend_component: f64,      // sub-composite: trend signals only
    momentum_component: f64,   // sub-composite: momentum signals only
    regime_component: f64,     // sub-composite: regime/vol signals only
    n_active: usize,           // number of non-NaN signals this bar
    conviction: f64,           // signal_strength × signal_alignment
}

// ─────────────────────────────────────────────────────────────────────────────
// Signal dimensions
// ─────────────────────────────────────────────────────────────────────────────

/// Compute alignment: what fraction of signals agree on direction with the
/// current bar's signal-weighted vote?
fn compute_alignment(signals: &[f64], weights: &[f64]) -> f64 {
    let weighted_direction: f64 = signals.iter()
        .zip(weights.iter())
        .filter(|(s, _)| s.is_finite())
        .map(|(s, w)| s.signum() * w)
        .sum();

    let total_weight: f64 = weights.iter()
        .zip(signals.iter())
        .filter(|(_, s)| s.is_finite())
        .map(|(w, _)| w)
        .sum();

    if total_weight < 1e-9 { return 0.0; }

    // Alignment = |sum of weighted signs| / total weight
    // 1.0 = all agree, 0.0 = perfectly split
    (weighted_direction / total_weight).abs()
}

/// Compute signal strength: ICIR-weighted mean of |signal value|, normalised.
/// Signals are assumed to be roughly Z-scored in [-3, 3].
fn compute_strength(signals: &[f64], weights: &[f64]) -> f64 {
    let weighted_abs: f64 = signals.iter()
        .zip(weights.iter())
        .filter(|(s, _)| s.is_finite())
        .map(|(s, w)| s.abs() * w)
        .sum();

    let total_weight: f64 = weights.iter()
        .zip(signals.iter())
        .filter(|(_, s)| s.is_finite())
        .map(|(w, _)| w)
        .sum();

    if total_weight < 1e-9 { return 0.0; }

    // Normalise: divide by 2.0 (typical strong signal ≈ 2σ → strength ≈ 1.0)
    (weighted_abs / total_weight / 2.0).min(1.0)
}

/// ICIR-weighted composite signal, with alignment gate.
/// Signals below min_alignment threshold are zeroed.
fn compute_composite(
    signals: &[f64],
    weights: &[f64],
    alignment: f64,
    min_alignment: f64,
) -> f64 {
    if alignment < min_alignment {
        return 0.0;  // no conviction — flat
    }

    let weighted_sum: f64 = signals.iter()
        .zip(weights.iter())
        .filter(|(s, _)| s.is_finite())
        .map(|(s, w)| s * w)
        .sum();

    let total_weight: f64 = weights.iter()
        .zip(signals.iter())
        .filter(|(_, s)| s.is_finite())
        .map(|(w, _)| w)
        .sum();

    if total_weight < 1e-9 { return 0.0; }

    // Scale by alignment so high-conviction bars have stronger signals
    (weighted_sum / total_weight) * alignment
}

/// Sub-composite for a subset of indices (by type: trend, momentum, regime)
fn sub_composite(signals: &[f64], weights: &[f64], indices: &[usize]) -> f64 {
    if indices.is_empty() { return 0.0; }

    let sub_signals: Vec<f64> = indices.iter().map(|&i| signals[i]).collect();
    let sub_weights: Vec<f64> = indices.iter().map(|&i| weights[i]).collect();

    let weighted_sum: f64 = sub_signals.iter()
        .zip(sub_weights.iter())
        .filter(|(s, _)| s.is_finite())
        .map(|(s, w)| s * w)
        .sum();

    let total_weight: f64 = sub_weights.iter()
        .zip(sub_signals.iter())
        .filter(|(_, s)| s.is_finite())
        .map(|(w, _)| w)
        .sum();

    if total_weight < 1e-9 { return 0.0; }
    weighted_sum / total_weight
}

// ─────────────────────────────────────────────────────────────────────────────
// Rolling alignment covariance (optional enrichment)
// Tracks rolling pairwise correlation to detect regime shifts.
// ─────────────────────────────────────────────────────────────────────────────

struct RollingStats {
    window: usize,
    n_signals: usize,
    /// Ring buffer: [bar_index % window][signal_index]
    buffer: Vec<Vec<f64>>,
    pos: usize,
    filled: usize,
}

impl RollingStats {
    fn new(window: usize, n_signals: usize) -> Self {
        Self {
            window,
            n_signals,
            buffer: vec![vec![0.0; n_signals]; window],
            pos: 0,
            filled: 0,
        }
    }

    fn push(&mut self, signals: &[f64]) {
        self.buffer[self.pos] = signals.to_vec();
        self.pos = (self.pos + 1) % self.window;
        self.filled = (self.filled + 1).min(self.window);
    }

    /// Mean pairwise correlation across all signal pairs in the rolling window.
    /// High = signals are in agreement (trending regime).
    /// Low = signals diverging (choppy/transitional regime).
    fn mean_pairwise_corr(&self) -> f64 {
        if self.filled < 10 { return 0.0; }

        let n = self.n_signals;
        let m = self.filled;
        let mut pair_corrs: Vec<f64> = Vec::new();

        for i in 0..n {
            for j in (i + 1)..n {
                let xi: Vec<f64> = (0..m).map(|k| {
                    let idx = (self.pos + self.window - m + k) % self.window;
                    self.buffer[idx][i]
                }).collect();
                let xj: Vec<f64> = (0..m).map(|k| {
                    let idx = (self.pos + self.window - m + k) % self.window;
                    self.buffer[idx][j]
                }).collect();

                let valid: Vec<(f64, f64)> = xi.iter().zip(xj.iter())
                    .filter(|(a, b)| a.is_finite() && b.is_finite())
                    .map(|(&a, &b)| (a, b))
                    .collect();

                if valid.len() < 5 { continue; }

                let n_v = valid.len() as f64;
                let mean_i = valid.iter().map(|(a, _)| a).sum::<f64>() / n_v;
                let mean_j = valid.iter().map(|(_, b)| b).sum::<f64>() / n_v;

                let cov: f64 = valid.iter()
                    .map(|(a, b)| (a - mean_i) * (b - mean_j))
                    .sum::<f64>() / n_v;

                let std_i = (valid.iter().map(|(a, _)| (a - mean_i).powi(2)).sum::<f64>() / n_v).sqrt();
                let std_j = (valid.iter().map(|(_, b)| (b - mean_j).powi(2)).sum::<f64>() / n_v).sqrt();

                if std_i > 1e-9 && std_j > 1e-9 {
                    pair_corrs.push(cov / (std_i * std_j));
                }
            }
        }

        if pair_corrs.is_empty() { return 0.0; }
        pair_corrs.iter().sum::<f64>() / pair_corrs.len() as f64
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// I/O helpers
// ─────────────────────────────────────────────────────────────────────────────

fn load_scores(path: &PathBuf) -> anyhow::Result<Vec<IndicatorMeta>> {
    let file = File::open(path)?;
    let mut rdr = ReaderBuilder::new().has_headers(true).from_reader(BufReader::new(file));

    let headers = rdr.headers()?.clone();
    let col = |name: &str| -> usize {
        headers.iter().position(|h| h == name).unwrap_or(0)
    };

    let mut metas = Vec::new();
    for result in rdr.records() {
        let record = result?;
        metas.push(IndicatorMeta {
            name:            record.get(col("name")).unwrap_or("").to_string(),
            sig_type:        record.get(col("type")).unwrap_or("").to_string(),
            icir:            record.get(col("icir")).unwrap_or("0").parse::<f64>().unwrap_or(0.0),
            composite_score: record.get(col("composite_score")).unwrap_or("0").parse::<f64>().unwrap_or(0.0),
        });
    }

    Ok(metas)
}

fn load_signals(path: &PathBuf, indicator_names: &[String]) -> anyhow::Result<Vec<SignalBar>> {
    let file = File::open(path)?;
    let mut rdr = ReaderBuilder::new().has_headers(true).from_reader(BufReader::new(file));

    let headers = rdr.headers()?.clone();
    // Find column index for each indicator
    let col_indices: Vec<Option<usize>> = indicator_names.iter()
        .map(|name| headers.iter().position(|h| h == name.as_str()))
        .collect();

    let date_col = headers.iter().position(|h| h == "date").unwrap_or(0);

    let mut bars = Vec::new();
    for result in rdr.records() {
        let record = result?;
        let date = record.get(date_col).unwrap_or("").to_string();
        let values: Vec<f64> = col_indices.iter().map(|opt_idx| {
            opt_idx
                .and_then(|idx| record.get(idx))
                .and_then(|v| v.parse::<f64>().ok())
                .unwrap_or(f64::NAN)
        }).collect();

        bars.push(SignalBar { date, values });
    }

    Ok(bars)
}

// ─────────────────────────────────────────────────────────────────────────────
// Main
// ─────────────────────────────────────────────────────────────────────────────

fn main() -> anyhow::Result<()> {
    let args = Args::parse();

    // Load indicator metadata (weights)
    let metas = load_scores(&args.scores)?;
    println!("Loaded {} indicator scores", metas.len());

    // ICIR-based weights (floor at 0.1 so low-quality signals still contribute a little)
    let weights: Vec<f64> = metas.iter()
        .map(|m| m.icir.max(0.1))
        .collect();

    // Normalise weights to sum to 1
    let weight_sum: f64 = weights.iter().sum();
    let weights: Vec<f64> = weights.iter()
        .map(|w| w / weight_sum)
        .collect();

    // Type indices for sub-composites
    let trend_idx: Vec<usize> = metas.iter().enumerate()
        .filter(|(_, m)| m.sig_type == "trend")
        .map(|(i, _)| i)
        .collect();

    let momentum_idx: Vec<usize> = metas.iter().enumerate()
        .filter(|(_, m)| m.sig_type == "momentum")
        .map(|(i, _)| i)
        .collect();

    let regime_idx: Vec<usize> = metas.iter().enumerate()
        .filter(|(_, m)| matches!(m.sig_type.as_str(), "regime" | "vol"))
        .map(|(i, _)| i)
        .collect();

    // Load signals
    let indicator_names: Vec<String> = metas.iter().map(|m| m.name.clone()).collect();
    let bars = load_signals(&args.signals, &indicator_names)?;
    println!("Loaded {} bars of signal data", bars.len());

    // Rolling stats tracker
    let mut rolling = RollingStats::new(args.align_window, metas.len());

    // Output
    let out_file = File::create(&args.output)?;
    let mut wtr = csv::Writer::from_writer(BufWriter::new(out_file));

    let mut n_active_total = 0usize;
    let n_bars = bars.len();

    for bar in &bars {
        let sigs = &bar.values;
        let n_active = sigs.iter().filter(|s| s.is_finite()).count();
        n_active_total += n_active;

        rolling.push(sigs);

        let alignment = compute_alignment(sigs, &weights);
        let strength  = compute_strength(sigs, &weights);
        let composite = compute_composite(sigs, &weights, alignment, args.min_alignment);

        let trend_comp    = sub_composite(sigs, &weights, &trend_idx);
        let momentum_comp = sub_composite(sigs, &weights, &momentum_idx);
        let regime_comp   = sub_composite(sigs, &weights, &regime_idx);

        let conviction = strength * alignment;

        wtr.serialize(CompositeBar {
            date:               bar.date.clone(),
            composite_signal:   (composite * 1000.0).round() / 1000.0,
            signal_strength:    (strength * 1000.0).round() / 1000.0,
            signal_alignment:   (alignment * 1000.0).round() / 1000.0,
            trend_component:    (trend_comp * 1000.0).round() / 1000.0,
            momentum_component: (momentum_comp * 1000.0).round() / 1000.0,
            regime_component:   (regime_comp * 1000.0).round() / 1000.0,
            n_active,
            conviction:         (conviction * 1000.0).round() / 1000.0,
        })?;
    }

    wtr.flush()?;

    let avg_active = n_active_total as f64 / n_bars as f64;
    println!("Wrote {} composite bars to {:?}", n_bars, args.output);
    println!("Avg active signals per bar: {:.1}", avg_active);

    Ok(())
}

// ─────────────────────────────────────────────────────────────────────────────
// Cargo.toml (paste into a new file at signal_combiner/Cargo.toml)
// ─────────────────────────────────────────────────────────────────────────────
//
// [package]
// name = "signal_combiner"
// version = "0.1.0"
// edition = "2021"
//
// [dependencies]
// clap    = { version = "4", features = ["derive"] }
// csv     = "1.3"
// serde   = { version = "1", features = ["derive"] }
// anyhow  = "1"
//
// [profile.release]
// opt-level = 3
// lto = true
// codegen-units = 1
