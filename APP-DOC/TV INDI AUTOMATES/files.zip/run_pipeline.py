#!/usr/bin/env python3
"""
run_pipeline.py
---------------
End-to-end: score indicators → export signal matrix → run Rust combiner.

Usage:
    python run_pipeline.py --data btc_1d.csv

Expects:
  - indicator_scorer.py in the same directory
  - signal_combiner binary built from signal_combiner.rs (cargo build --release)
"""

import subprocess
import sys
import argparse
from pathlib import Path
import numpy as np
import pandas as pd


def build_signal_matrix(df: pd.DataFrame, output_path: str) -> pd.DataFrame:
    """
    Generate the signal matrix CSV: one row per bar, one column per indicator.
    This is the input the Rust combiner consumes.
    """
    from indicator_scorer import SIGNAL_REGISTRY

    print("Building signal matrix...")
    signal_cols = {"date": df.index.strftime("%Y-%m-%d")}

    for name, meta in SIGNAL_REGISTRY.items():
        try:
            sig = meta["fn"](df)
            # Winsorize to [-4, 4] so outliers don't blow up weights
            sig = sig.clip(-4, 4)
            signal_cols[name] = sig.values
        except Exception as e:
            print(f"  [!] {name} failed: {e}")
            signal_cols[name] = np.full(len(df), np.nan)

    sig_df = pd.DataFrame(signal_cols)
    sig_df.to_csv(output_path, index=False)
    print(f"Signal matrix: {sig_df.shape[0]} bars × {len(SIGNAL_REGISTRY)} signals → {output_path}")
    return sig_df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True, help="OHLCV CSV")
    parser.add_argument("--combiner", default="./signal_combiner/target/release/signal_combiner")
    args = parser.parse_args()

    data_path = Path(args.data)
    scores_path = Path("ranked_indicators.csv")
    signals_path = Path("signals_matrix.csv")
    composite_path = Path("composite_signal.csv")

    # Load data
    df = pd.read_csv(data_path, parse_dates=["date"], index_col="date")
    df.columns = df.columns.str.lower()
    df = df.loc["2018-01-01":]
    print(f"Loaded {len(df)} bars from {df.index[0].date()} to {df.index[-1].date()}")

    # Step 1: Score indicators
    print("\n=== Step 1: Scoring indicators ===")
    from indicator_scorer import score_all_signals
    scores_df = score_all_signals(df)
    scores_df.to_csv(scores_path, index=False)
    print(f"\nTop 5 indicators:")
    print(scores_df.head(5)[["rank", "name", "type", "icir", "composite_score"]].to_string(index=False))

    # Step 2: Build signal matrix
    print("\n=== Step 2: Building signal matrix ===")
    build_signal_matrix(df, str(signals_path))

    # Step 3: Run Rust combiner
    combiner_path = Path(args.combiner)
    if not combiner_path.exists():
        print(f"\n[!] Rust combiner not found at {combiner_path}")
        print("Build it with:")
        print("  mkdir -p signal_combiner/src")
        print("  cp signal_combiner.rs signal_combiner/src/main.rs")
        print("  # create Cargo.toml (see comments in signal_combiner.rs)")
        print("  cd signal_combiner && cargo build --release")

        # Python fallback combiner
        print("\nRunning Python fallback combiner...")
        _python_fallback_combine(signals_path, scores_path, composite_path)
    else:
        print(f"\n=== Step 3: Running Rust combiner ===")
        result = subprocess.run([
            str(combiner_path),
            "--signals", str(signals_path),
            "--scores",  str(scores_path),
            "--output",  str(composite_path),
            "--min-alignment", "0.20",
        ], capture_output=True, text=True)
        print(result.stdout)
        if result.returncode != 0:
            print(f"[!] Rust combiner error: {result.stderr}")
            sys.exit(1)

    # Show summary
    comp = pd.read_csv(composite_path)
    print(f"\n=== Composite Signal Summary ===")
    print(f"Bars: {len(comp)}")
    print(f"Composite signal  — mean: {comp.composite_signal.mean():.3f}  std: {comp.composite_signal.std():.3f}")
    print(f"Signal strength   — mean: {comp.signal_strength.mean():.3f}")
    print(f"Signal alignment  — mean: {comp.signal_alignment.mean():.3f}")
    print(f"Conviction (s×a)  — mean: {comp.conviction.mean():.3f}")
    long_bars  = (comp.composite_signal > 0.1).sum()
    short_bars = (comp.composite_signal < -0.1).sum()
    flat_bars  = len(comp) - long_bars - short_bars
    print(f"Signal direction  — long: {long_bars} | flat: {flat_bars} | short: {short_bars}")


def _python_fallback_combine(
    signals_path: Path,
    scores_path: Path,
    output_path: Path,
):
    """Pure Python fallback if Rust binary isn't available."""
    sigs = pd.read_csv(signals_path, parse_dates=["date"], index_col="date")
    scores = pd.read_csv(scores_path)

    # ICIR weights
    weight_map = dict(zip(scores["name"], scores["icir"].clip(lower=0.1)))
    cols = [c for c in sigs.columns if c in weight_map]
    weights = np.array([weight_map[c] for c in cols])
    weights = weights / weights.sum()

    type_map = dict(zip(scores["name"], scores["type"]))
    trend_idx    = [i for i, c in enumerate(cols) if type_map.get(c) == "trend"]
    momentum_idx = [i for i, c in enumerate(cols) if type_map.get(c) == "momentum"]
    regime_idx   = [i for i, c in enumerate(cols) if type_map.get(c) in ("regime", "vol")]

    rows = []
    for date, row in sigs[cols].iterrows():
        sv = row.values.astype(float)
        finite = np.isfinite(sv)
        n_active = int(finite.sum())

        if n_active == 0:
            rows.append({"date": date, "composite_signal": 0.0, "signal_strength": 0.0,
                         "signal_alignment": 0.0, "conviction": 0.0, "n_active": 0,
                         "trend_component": 0.0, "momentum_component": 0.0, "regime_component": 0.0})
            continue

        sv_clean = np.where(finite, sv, 0.0)

        # Alignment: |weighted sum of signs| / total weight on finite signals
        weighted_signs = np.sum(np.sign(sv_clean) * weights * finite)
        total_w = np.sum(weights * finite)
        alignment = abs(weighted_signs / total_w) if total_w > 1e-9 else 0.0

        # Strength: weighted mean of |signal| / 2
        strength = min(np.sum(np.abs(sv_clean) * weights * finite) / (total_w * 2.0 + 1e-9), 1.0)

        # Composite
        composite = 0.0
        if alignment >= 0.20:
            composite = np.sum(sv_clean * weights * finite) / (total_w + 1e-9) * alignment

        def sub_comp(indices):
            if not indices: return 0.0
            ix = np.array(indices)
            w = weights[ix] * finite[ix]
            sw = w.sum()
            if sw < 1e-9: return 0.0
            return float(np.sum(sv_clean[ix] * w) / sw)

        rows.append({
            "date":               date,
            "composite_signal":   round(composite, 4),
            "signal_strength":    round(strength, 4),
            "signal_alignment":   round(alignment, 4),
            "trend_component":    round(sub_comp(trend_idx), 4),
            "momentum_component": round(sub_comp(momentum_idx), 4),
            "regime_component":   round(sub_comp(regime_idx), 4),
            "n_active":           n_active,
            "conviction":         round(strength * alignment, 4),
        })

    pd.DataFrame(rows).to_csv(output_path, index=False)
    print(f"Python fallback composite written to {output_path}")


if __name__ == "__main__":
    main()
